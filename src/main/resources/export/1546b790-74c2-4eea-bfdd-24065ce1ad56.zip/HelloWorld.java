public class HelloWorld {
    public static void main(String[] args) {
        SayHello s = new SayHello();
	s.sayHelloMain();
    }
}
