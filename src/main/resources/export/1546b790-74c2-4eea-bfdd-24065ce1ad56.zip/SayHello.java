public class SayHello {
    public void sayHelloMain(){
	System.out.println("HELLO");    
}
}
