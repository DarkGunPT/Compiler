#include <stdio.h>

void printHello() {
    printf("Hello, project!");
}
