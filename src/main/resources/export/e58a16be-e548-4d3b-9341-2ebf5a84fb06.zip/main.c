#include <stdio.h>

int main() {
    printf("Hello, file!");
    return 0;
}