#include <stdio.h>

void printHello();
int main() {
    printHello();
    return 0;
}